﻿namespace STUDENTSCOURSE
{
    partial class StudentManagment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxStudenInfo = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.radioFemale = new System.Windows.Forms.RadioButton();
            this.radioMale = new System.Windows.Forms.RadioButton();
            this.NumAge = new System.Windows.Forms.TextBox();
            this.TestStudentID = new System.Windows.Forms.TextBox();
            this.TestStudentName = new System.Windows.Forms.TextBox();
            this.COURSES = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.extracurricular = new System.Windows.Forms.RadioButton();
            this.Resultlabal = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBoxStudenInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxStudenInfo
            // 
            this.groupBoxStudenInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.groupBoxStudenInfo.Controls.Add(this.label3);
            this.groupBoxStudenInfo.Controls.Add(this.label2);
            this.groupBoxStudenInfo.Controls.Add(this.label1);
            this.groupBoxStudenInfo.Controls.Add(this.radioFemale);
            this.groupBoxStudenInfo.Controls.Add(this.radioMale);
            this.groupBoxStudenInfo.Controls.Add(this.NumAge);
            this.groupBoxStudenInfo.Controls.Add(this.TestStudentID);
            this.groupBoxStudenInfo.Controls.Add(this.TestStudentName);
            this.groupBoxStudenInfo.Location = new System.Drawing.Point(316, 34);
            this.groupBoxStudenInfo.Name = "groupBoxStudenInfo";
            this.groupBoxStudenInfo.Size = new System.Drawing.Size(539, 268);
            this.groupBoxStudenInfo.TabIndex = 0;
            this.groupBoxStudenInfo.TabStop = false;
            this.groupBoxStudenInfo.Text = "groupBoxStudentInfo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Enter Age";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Enter ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Enter Name";
            // 
            // radioFemale
            // 
            this.radioFemale.AutoSize = true;
            this.radioFemale.Location = new System.Drawing.Point(234, 196);
            this.radioFemale.Name = "radioFemale";
            this.radioFemale.Size = new System.Drawing.Size(87, 24);
            this.radioFemale.TabIndex = 4;
            this.radioFemale.TabStop = true;
            this.radioFemale.Text = "Female";
            this.radioFemale.UseVisualStyleBackColor = true;
            // 
            // radioMale
            // 
            this.radioMale.AutoSize = true;
            this.radioMale.Location = new System.Drawing.Point(54, 196);
            this.radioMale.Name = "radioMale";
            this.radioMale.Size = new System.Drawing.Size(68, 24);
            this.radioMale.TabIndex = 3;
            this.radioMale.TabStop = true;
            this.radioMale.Text = "Male";
            this.radioMale.UseVisualStyleBackColor = true;
            // 
            // NumAge
            // 
            this.NumAge.Location = new System.Drawing.Point(137, 136);
            this.NumAge.Name = "NumAge";
            this.NumAge.Size = new System.Drawing.Size(156, 26);
            this.NumAge.TabIndex = 2;
            this.NumAge.TextChanged += new System.EventHandler(this.NumAge_TextChanged);
            // 
            // TestStudentID
            // 
            this.TestStudentID.Location = new System.Drawing.Point(137, 89);
            this.TestStudentID.Name = "TestStudentID";
            this.TestStudentID.Size = new System.Drawing.Size(156, 26);
            this.TestStudentID.TabIndex = 1;
            // 
            // TestStudentName
            // 
            this.TestStudentName.Location = new System.Drawing.Point(137, 44);
            this.TestStudentName.Name = "TestStudentName";
            this.TestStudentName.Size = new System.Drawing.Size(246, 26);
            this.TestStudentName.TabIndex = 0;
            // 
            // COURSES
            // 
            this.COURSES.FormattingEnabled = true;
            this.COURSES.ItemHeight = 20;
            this.COURSES.Items.AddRange(new object[] {
            "JAVA",
            "C#",
            "HTML&&CSS",
            "React"});
            this.COURSES.Location = new System.Drawing.Point(370, 299);
            this.COURSES.Name = "COURSES";
            this.COURSES.Size = new System.Drawing.Size(173, 84);
            this.COURSES.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(404, 542);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 79);
            this.button1.TabIndex = 5;
            this.button1.Text = "S&ubmit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Lime;
            this.button2.Location = new System.Drawing.Point(534, 542);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 79);
            this.button2.TabIndex = 6;
            this.button2.Text = "C&lear";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Lime;
            this.button3.Location = new System.Drawing.Point(690, 542);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 79);
            this.button3.TabIndex = 7;
            this.button3.Text = "E&xit";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // extracurricular
            // 
            this.extracurricular.AutoSize = true;
            this.extracurricular.Location = new System.Drawing.Point(657, 340);
            this.extracurricular.Name = "extracurricular";
            this.extracurricular.Size = new System.Drawing.Size(138, 24);
            this.extracurricular.TabIndex = 8;
            this.extracurricular.TabStop = true;
            this.extracurricular.Text = "extra-curricular";
            this.extracurricular.UseVisualStyleBackColor = true;
            // 
            // Resultlabal
            // 
            this.Resultlabal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Resultlabal.Location = new System.Drawing.Point(378, 386);
            this.Resultlabal.Name = "Resultlabal";
            this.Resultlabal.Size = new System.Drawing.Size(403, 134);
            this.Resultlabal.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::STUDENTSCOURSE.Properties.Resources.log;
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(219, 224);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // StudentManagment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(1165, 650);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Resultlabal);
            this.Controls.Add(this.extracurricular);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.COURSES);
            this.Controls.Add(this.groupBoxStudenInfo);
            this.Name = "StudentManagment";
            this.Text = "Student Managment Form";
            this.groupBoxStudenInfo.ResumeLayout(false);
            this.groupBoxStudenInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxStudenInfo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioFemale;
        private System.Windows.Forms.RadioButton radioMale;
        private System.Windows.Forms.TextBox NumAge;
        private System.Windows.Forms.TextBox TestStudentID;
        private System.Windows.Forms.TextBox TestStudentName;
        private System.Windows.Forms.ListBox COURSES;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RadioButton extracurricular;
        private System.Windows.Forms.Label Resultlabal;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

