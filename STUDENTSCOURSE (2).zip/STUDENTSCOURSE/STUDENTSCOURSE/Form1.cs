﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STUDENTSCOURSE
{
    public partial class StudentManagment : Form
    {
        public StudentManagment()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string STName;
                int STID;
                int AGE;
                string GENDER;
                string course;
                bool EXTRACURRICULAR;
                STName = TestStudentName.Text;
                STID = int.Parse(TestStudentID.Text);
                AGE = int.Parse(NumAge.Text);
                GENDER = radioMale.Checked ? "Male" : "Female";
                course = COURSES.Text;
                EXTRACURRICULAR = extracurricular.Checked;
                if (AGE >= 18 && AGE <= 30)
                {
                    if (radioFemale.Checked)
                    {

                        if (COURSES.SelectedIndex != -1)
                        {
                            course = COURSES.SelectedItem.ToString();
                            switch (course)
                            {
                                case "JAVA":
                                    Resultlabal.Text = "NAME:" + STName + "\nID:" + STID.ToString() + "\nAGE:" +
                                        AGE.ToString() + "\nGENDER:" + GENDER + "\nCOURSE:"
                                        + course.ToString() + "extracurricular:" + (EXTRACURRICULAR ? "YES" : "NO");
                                    break;

                                case "C#":
                                    Resultlabal.Text = "NAME :" + STName + "\nID:" + STID.ToString() + "\nAGE:" +
                                        AGE.ToString() + "\nGENDER:" + GENDER + "\nCOURSE:"
                                        + course.ToString() + "\n extracurricular:" + (EXTRACURRICULAR ? "YES" : "NO"); break;

                                case "HTML&&CSS":
                                    Resultlabal.Text = "NAME:" + STName + "\nID:" + STID.ToString() + "\nAGE:" +
                                        AGE.ToString() + "\nGENDER:" + GENDER + "\nCOURSE:"
                                        + course.ToString() + "extracurricular:" + (EXTRACURRICULAR ? "YES" : "NO"); break;

                                case "React":
                                    Resultlabal.Text = "NAME:" + STName + "\nID:" + STID.ToString() + "\nAGE:" +
                                        AGE.ToString() + "\nGENDER:" + GENDER + "\nCOURSE:"
                                        + course.ToString() + "\n extracurricular:" + (EXTRACURRICULAR ? "YES" : "NO"); break;

                            }

                            Resultlabal.Text = "NAME :" + STName + "\nID:" + STID.ToString() + "\nAGE:" +
                                AGE.ToString() + "\nGENDER:" + GENDER + "\nCOURSE:"
                                + course.ToString() + "\n extracurricular:" + (EXTRACURRICULAR ? "YES" : "NO");

                        }
                        else
                        {
                            MessageBox.Show("you must select at least one course");
                        }
                    }
                    else if (radioMale.Checked)
                    {
                        if (COURSES.SelectedIndex != -1)
                        {
                            course = COURSES.SelectedItem.ToString();
                            switch (course)
                            {

                                case "JAVA":
                                    Resultlabal.Text = "NAME:" + STName + "\nID" + STID.ToString() + "\nAGE" +
                                        AGE.ToString() + "\nGENDER:" + GENDER + "\nCOURSE:"
                                        + course.ToString() + "\n extracurricular:" + (EXTRACURRICULAR ? "YES" : "NO"); break;
                                case "C#":
                                    Resultlabal.Text = "NAME:" + STName + "\nID:" + STID.ToString() + "\nAGE:" +
                                        AGE.ToString() + "\nGENDER:" + GENDER + "\nCOURSE:"
                                        + course.ToString() + "\n extracurricular:" + (EXTRACURRICULAR ? "YES" : "NO"); break;
                                case "HTML&&CSS":
                                    Resultlabal.Text = "NAME:" + STName + "\nID:" + STID.ToString() + "\nAGE:" +
                                        AGE.ToString() + "\nGENDER:" + GENDER + "\nCOURSE:"
                                        + course.ToString() + "\n extracurricular:" + (EXTRACURRICULAR ? "YES" : "NO"); break;
                                case "React":
                                    Resultlabal.Text = "NAME:" + STName + "\nID:" + STID.ToString() + "\nAGE:" +
                                        AGE.ToString() + "\nGENDER:" + GENDER + "\nCOURSE:"
                                        + course.ToString() + "\n extracurricular:" + (EXTRACURRICULAR ? "YES" : "NO"); break;
                                    Resultlabal.BackColor = Color.DarkOliveGreen;
                                    button1.BackColor = Color.Gray;
                            }
                        }
                        else
                        {
                            MessageBox.Show("You must select at least one course");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select the gender");
                    }
                }
                else
                {
                    MessageBox.Show("the age must between  18 AND  30");
                }
            }
            catch (Exception LIST)
            {
                MessageBox.Show(LIST.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TestStudentName.Text="";
            TestStudentID.Clear();
            NumAge.Text = "";
            radioFemale.Checked = false;
            radioMale.Checked = false;
            COURSES.ClearSelected();
            extracurricular.Checked = false;
            Resultlabal.Text = "";
            button2.BackColor = Color.Gray;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            button2.BackColor = Color.Gray;
        }

        private void NumAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
